package edu.psu.se411.lab11_inventory.model;

public enum DeviceCategory {
    COMPUTER,
    SMARTPHONE,
    TABLET,
    LAPTOP,
    MOBILE,
    GAMING,
    WEARABLE,
    AUDIO
}
